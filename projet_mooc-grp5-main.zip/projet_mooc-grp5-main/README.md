# projet_mooc
Projet Mooc : identifier les apprenants qui vont finir le cours et monitorer la formation

# schema fonctionnel

![brief-mooc-66445a7dde903686763822-1](https://github.com/RTenaille/projet_mooc/assets/118723783/ddddec07-e39d-4d62-91c6-4e210f14eba5)
