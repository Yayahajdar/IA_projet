import tensorflow as tf
print("TensorFlow version:", tf.__version__)

